import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { User, Science, FlaskConical, FileText, Award, Mail, Building, Shield, Moon, Bell, Lock, Download, Settings, LogOut, ChevronRight } from 'lucide-react';
import BottomNav from '../components/BottomNav';

const ProfileScreen = () => {
  const navigate = useNavigate();
  const [darkMode, setDarkMode] = useState(false);
  const [notifications, setNotifications] = useState(true);

  const handleLogout = () => {
    localStorage.removeItem('token');
    navigate('/login');
  };

  return (
    <div className="dashboard-container">
      {/* Header Profile Info Gradient */}
      <div style={{ height: 280, background: 'linear-gradient(180deg, #2563EB 0%, #0D9488 100%)', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', position: 'relative' }}>
        
        <div style={{ position: 'relative', width: 90, height: 90 }}>
          <div style={{ width: 90, height: 90, backgroundColor: 'white', borderRadius: '50%', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
            <User size={40} color="#3B82F6" />
          </div>
          <div style={{ position: 'absolute', bottom: -4, right: -4, width: 24, height: 24, backgroundColor: '#22C55E', borderRadius: '50%', border: '3px solid white' }}></div>
        </div>
        
        <div style={{ marginTop: 16, color: 'white', fontSize: 24, fontWeight: 'bold' }}>Dr. Sarah Chen</div>
        <div style={{ color: 'rgba(255,255,255,0.8)', fontSize: 14, marginTop: 4 }}>sarah.chen@research.edu</div>
        <div style={{ color: 'rgba(255,255,255,0.7)', fontSize: 12, marginTop: 4 }}>Pharmaceutical Research Scientist</div>
      </div>

      {/* Content Starts Overlapping the Header */}
      <div className="dashboard-content" style={{ marginTop: -80, padding: '0 20px', zIndex: 10 }}>
        
        {/* Stats Row */}
        <div style={{ display: 'flex', gap: 12, marginBottom: 20 }}>
          <StatCard icon={FlaskConical} color="#3B82F6" value="24" label="Total Analyses" />
          <StatCard icon={FileText} color="#10B981" value="18" label="Reports Saved" />
          <StatCard icon={Award} color="#8B5CF6" value="94%" label="Accuracy Rate" />
        </div>

        {/* sections */}
        <ProfileSection title="Account Information">
          <InfoItem icon={Mail} color="#3B82F6" label="Email" value="sarah.chen@research.edu" />
          <InfoItem icon={Building} color="#0D9488" label="Organization" value="BioPharma Research Institute" />
          <InfoItem icon={Shield} color="#8B5CF6" label="Account Type" value="Premium Researcher" />
        </ProfileSection>

        <ProfileSection title="Preferences">
          <ToggleItem icon={Moon} color="#1E293B" title="Dark Mode" subtitle="Enable dark theme" checked={darkMode} onChange={() => setDarkMode(!darkMode)} />
          <ToggleItem icon={Bell} color="#F59E0B" title="Notifications" subtitle="Analysis updates" checked={notifications} onChange={() => setNotifications(!notifications)} />
        </ProfileSection>

        <ProfileSection title="Actions">
          <ActionItem icon={Lock} title="Change Password" />
          <ActionItem icon={Download} title="Export All Reports" />
          <ActionItem icon={Settings} title="Advanced Settings" />
        </ProfileSection>

        <button 
          onClick={handleLogout}
          style={{ width: '100%', height: 56, backgroundColor: '#FEF2F2', color: '#EF4444', borderRadius: 16, border: 'none', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 16, fontWeight: 600, marginTop: 32, cursor: 'pointer' }}
        >
          <LogOut size={20} style={{ marginRight: 12 }} />
          Sign Out
        </button>

        <div style={{ textAlign: 'center', marginTop: 32, paddingBottom: 32 }}>
          <div style={{ color: 'gray', fontSize: 12 }}>DiaSafe AI v1.0.0</div>
          <div style={{ color: 'gray', fontSize: 11, marginTop: 4 }}>© 2026 BioPharma Research</div>
        </div>

      </div>

      <BottomNav />
    </div>
  );
};

// UI Components mirroring Android structure
const StatCard = ({ icon: Icon, color, value, label }) => (
  <div style={{ flex: 1, backgroundColor: 'white', borderRadius: 16, padding: 12, display: 'flex', flexDirection: 'column', alignItems: 'center', boxShadow: '0 4px 15px rgba(0,0,0,0.05)' }}>
    <div style={{ width: 36, height: 36, borderRadius: 10, backgroundColor: `${color}1A`, display: 'flex', justifyContent: 'center', alignItems: 'center', marginBottom: 8 }}>
      <Icon size={20} color={color} />
    </div>
    <div style={{ fontSize: 18, fontWeight: 'bold', color: '#1E293B' }}>{value}</div>
    <div style={{ fontSize: 10, color: 'gray', textAlign: 'center' }}>{label}</div>
  </div>
);

const ProfileSection = ({ title, children }) => (
  <div style={{ marginBottom: 20 }}>
    <div style={{ fontSize: 18, fontWeight: 'bold', color: '#1E293B', marginBottom: 12 }}>{title}</div>
    <div style={{ backgroundColor: 'white', borderRadius: 20, padding: 8, boxShadow: '0 4px 15px rgba(0,0,0,0.02)' }}>
      {children}
    </div>
  </div>
);

const InfoItem = ({ icon: Icon, color, label, value }) => (
  <div style={{ display: 'flex', alignItems: 'center', padding: 12, backgroundColor: '#F8FAFC', borderRadius: 12, marginBottom: 8 }}>
    <div style={{ width: 40, height: 40, borderRadius: 10, backgroundColor: `${color}1A`, display: 'flex', justifyContent: 'center', alignItems: 'center', marginRight: 16 }}>
      <Icon size={20} color={color} />
    </div>
    <div>
      <div style={{ fontSize: 11, color: 'gray' }}>{label}</div>
      <div style={{ fontSize: 14, fontWeight: 600, color: '#334155' }}>{value}</div>
    </div>
  </div>
);

const ToggleItem = ({ icon: Icon, color, title, subtitle, checked, onChange }) => (
  <div style={{ display: 'flex', alignItems: 'center', padding: 12, backgroundColor: '#F8FAFC', borderRadius: 12, marginBottom: 8 }}>
    <div style={{ width: 40, height: 40, borderRadius: 10, backgroundColor: `${color}1A`, display: 'flex', justifyContent: 'center', alignItems: 'center', marginRight: 16 }}>
      <Icon size={20} color={color} />
    </div>
    <div style={{ flex: 1 }}>
      <div style={{ fontSize: 15, fontWeight: 600, color: '#334155' }}>{title}</div>
      <div style={{ fontSize: 12, color: 'gray' }}>{subtitle}</div>
    </div>
    <label style={{ position: 'relative', display: 'inline-block', width: 44, height: 24 }}>
      <input type="checkbox" checked={checked} onChange={onChange} style={{ opacity: 0, width: 0, height: 0 }} />
      <span style={{ 
        position: 'absolute', cursor: 'pointer', top: 0, left: 0, right: 0, bottom: 0, 
        backgroundColor: checked ? '#3B82F6' : '#ccc', transition: '.4s', borderRadius: 24 
      }}>
        <span style={{
          position: 'absolute', content: '""', height: 18, width: 18, left: 3, bottom: 3, 
          backgroundColor: 'white', transition: '.4s', borderRadius: '50%',
          transform: checked ? 'translateX(20px)' : 'translateX(0)'
        }}></span>
      </span>
    </label>
  </div>
);

const ActionItem = ({ icon: Icon, title }) => (
  <div style={{ display: 'flex', alignItems: 'center', padding: 12, backgroundColor: '#F8FAFC', borderRadius: 12, marginBottom: 8, cursor: 'pointer' }}>
    <div style={{ width: 40, height: 40, borderRadius: 10, backgroundColor: 'rgba(59, 130, 246, 0.05)', display: 'flex', justifyContent: 'center', alignItems: 'center', marginRight: 16 }}>
      <Icon size={20} color="#3B82F6" />
    </div>
    <div style={{ flex: 1, fontSize: 15, fontWeight: 600, color: '#334155' }}>{title}</div>
    <ChevronRight size={16} color="lightgray" />
  </div>
);

export default ProfileScreen;
