import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { User, Lock, Mail, Eye, EyeOff, ArrowRight, FlaskConical } from 'lucide-react';

const LoginScreen = () => {
  const [isSignInTab, setIsSignInTab] = useState(true);
  const navigate = useNavigate();

  return (
    <div className="auth-container">
      <div className="auth-wrapper">
        <div className="logo-container">
          <FlaskConical size={48} color="#1B85E7" />
        </div>
        
        <div className="brand-title">
          <span className="brand-diasafe">DiaSafe</span>
          <span className="brand-ai"> AI</span>
        </div>
        
        <p className="brand-subtitle">AI-Powered Drug Toxicity Analysis</p>

        <div className="auth-card">
          <div className="tab-selector">
            <button 
              className={`tab-btn ${isSignInTab ? 'active' : ''}`}
              onClick={() => setIsSignInTab(true)}
            >
              Sign In
            </button>
            <button 
              className={`tab-btn ${!isSignInTab ? 'active' : ''}`}
              onClick={() => setIsSignInTab(false)}
            >
              Sign Up
            </button>
          </div>

          {isSignInTab ? (
            <SignInContent 
              onSwitchTab={() => setIsSignInTab(false)} 
              onLogin={() => navigate('/dashboard')} 
            />
          ) : (
            <SignUpContent 
              onSwitchTab={() => setIsSignInTab(true)} 
            />
          )}
        </div>

        <p className="terms-text">
          By continuing, you agree to our Terms of Service and Privacy Policy. This platform is for research purposes only.
        </p>
      </div>
    </div>
  );
};

const SignInContent = ({ onSwitchTab, onLogin }) => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [isPasswordVisible, setIsPasswordVisible] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [errors, setErrors] = useState({});

  const handleSignIn = async (e) => {
    e.preventDefault();
    let newErrors = {};
    if (!username) newErrors.username = 'This field is required';
    if (!password) newErrors.password = 'This field is required';

    if (Object.keys(newErrors).length > 0) {
      setErrors(newErrors);
      return;
    }

    setErrors({});
    setIsLoading(true);

    try {
      const response = await fetch('http://localhost:8000/api/login/', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username, password })
      });

      if (response.ok) {
        const data = await response.json();
        localStorage.setItem('token', data.access);
        onLogin();
      } else {
        alert('Invalid Credentials');
      }
    } catch (err) {
      alert('Network Error: ' + err.message);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <form onSubmit={handleSignIn}>
      <div className="input-group">
        <label className="input-label">Username</label>
        <div className="input-field-wrapper">
          <User className="input-icon" />
          <input 
            type="text" 
            className={`input-field ${errors.username ? 'error' : ''}`}
            placeholder="Enter your username"
            value={username}
            onChange={(e) => { setUsername(e.target.value); setErrors(p => ({...p, username: null})); }}
            disabled={isLoading}
          />
        </div>
        {errors.username && <div className="error-text">{errors.username}</div>}
      </div>

      <div className="input-group">
        <label className="input-label">Password</label>
        <div className="input-field-wrapper">
          <Lock className="input-icon" />
          <input 
            type={isPasswordVisible ? "text" : "password"}
            className={`input-field ${errors.password ? 'error' : ''}`}
            placeholder="Enter your password"
            value={password}
            onChange={(e) => { setPassword(e.target.value); setErrors(p => ({...p, password: null})); }}
            disabled={isLoading}
          />
          <button 
            type="button"
            className="input-action-icon"
            onClick={() => setIsPasswordVisible(!isPasswordVisible)}
          >
            {isPasswordVisible ? <EyeOff size={20} /> : <Eye size={20} />}
          </button>
        </div>
        {errors.password && <div className="error-text">{errors.password}</div>}
      </div>

      <div className="forgot-password">
        <a href="#forgot" onClick={(e) => e.preventDefault()}>Forgot password?</a>
      </div>

      <button type="submit" className="primary-btn" disabled={isLoading}>
        {isLoading ? <div className="loader"></div> : (
          <>
            Sign In
            <ArrowRight size={20} />
          </>
        )}
      </button>

      <div className="auth-footer-link">
        Don't have an account? <span onClick={onSwitchTab}>Sign Up</span>
      </div>
    </form>
  );
};

const SignUpContent = ({ onSwitchTab }) => {
  const [email, setEmail] = useState('');
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [isPasswordVisible, setIsPasswordVisible] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [errors, setErrors] = useState({});

  const handleSignUp = async (e) => {
    e.preventDefault();
    let newErrors = {};
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    
    if (!email) newErrors.email = 'This field is required';
    else if (!emailRegex.test(email)) newErrors.email = 'Enter a valid email address';
    
    if (!username) newErrors.username = 'This field is required';
    if (!password) newErrors.password = 'This field is required';

    if (Object.keys(newErrors).length > 0) {
      setErrors(newErrors);
      return;
    }

    setErrors({});
    setIsLoading(true);

    try {
      const response = await fetch('http://localhost:8000/api/register/', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, username, password })
      });

      if (response.ok) {
        alert('Registration Successful');
        onSwitchTab();
      } else {
        if (response.status === 400) {
          setErrors({ email: 'Email already registered' });
        } else {
          alert('Registration Failed');
        }
      }
    } catch (err) {
      alert('Network Error: ' + err.message);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <form onSubmit={handleSignUp}>
      <div className="input-group">
        <label className="input-label">Email Address</label>
        <div className="input-field-wrapper">
          <Mail className="input-icon" />
          <input 
            type="email" 
            className={`input-field ${errors.email ? 'error' : ''}`}
            placeholder="you@example.com"
            value={email}
            onChange={(e) => { setEmail(e.target.value); setErrors(p => ({...p, email: null})); }}
            disabled={isLoading}
          />
        </div>
        {errors.email && <div className="error-text">{errors.email}</div>}
      </div>

      <div className="input-group">
        <label className="input-label">Username</label>
        <div className="input-field-wrapper">
          <User className="input-icon" />
          <input 
            type="text" 
            className={`input-field ${errors.username ? 'error' : ''}`}
            placeholder="Enter your username"
            value={username}
            onChange={(e) => { setUsername(e.target.value); setErrors(p => ({...p, username: null})); }}
            disabled={isLoading}
          />
        </div>
        {errors.username && <div className="error-text">{errors.username}</div>}
      </div>

      <div className="input-group">
        <label className="input-label">Password</label>
        <div className="input-field-wrapper">
          <Lock className="input-icon" />
          <input 
            type={isPasswordVisible ? "text" : "password"}
            className={`input-field ${errors.password ? 'error' : ''}`}
            placeholder="Enter your password"
            value={password}
            onChange={(e) => { setPassword(e.target.value); setErrors(p => ({...p, password: null})); }}
            disabled={isLoading}
          />
          <button 
            type="button"
            className="input-action-icon"
            onClick={() => setIsPasswordVisible(!isPasswordVisible)}
          >
            {isPasswordVisible ? <EyeOff size={20} /> : <Eye size={20} />}
          </button>
        </div>
        {errors.password && <div className="error-text">{errors.password}</div>}
      </div>

      <button type="submit" className="primary-btn" disabled={isLoading} style={{ marginTop: 24 }}>
        {isLoading ? <div className="loader"></div> : (
          <>
            Sign Up
            <ArrowRight size={20} />
          </>
        )}
      </button>

      <div className="auth-footer-link">
        Already have an account? <span onClick={onSwitchTab}>Sign In</span>
      </div>
    </form>
  );
};

export default LoginScreen;
